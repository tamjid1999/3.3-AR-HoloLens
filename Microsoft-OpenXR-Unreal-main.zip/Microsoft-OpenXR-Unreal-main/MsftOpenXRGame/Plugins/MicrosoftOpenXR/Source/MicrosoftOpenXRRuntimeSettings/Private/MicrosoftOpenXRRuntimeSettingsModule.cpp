// Copyright (c) 2020 Microsoft Corporation.
// Licensed under the MIT License.

#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FDefaultModuleImpl, MicrosoftOpenXRRuntimeSettings);
