// Copyright (c) 2020 Microsoft Corporation.
// Licensed under the MIT License.

#include "NuGetModule.h"

IMPLEMENT_MODULE(FNuGetModule, NuGetModule)